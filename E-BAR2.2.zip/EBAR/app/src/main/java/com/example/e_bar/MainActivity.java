package com.example.e_bar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.e_bar.logica.barServiceArchive;

import java.io.File;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Context context = MainActivity.this;

        File directorio = context.getFilesDir();

        barServiceArchive.asignarArchivo(directorio.getAbsolutePath());

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_principal_1, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item1:
                Intent bar = new Intent(this, com.example.e_bar.bar.class);
                startActivity(bar);
                return true;
            case R.id.item2:
                Intent factura = new Intent(this, com.example.e_bar.factura.class);
                startActivity(factura);
                return true;
            case R.id.item3:
                Intent Eliminar = new Intent(this, com.example.e_bar.eliminar.class);
                startActivity(Eliminar);
                return true;
            case R.id.item4:
                Intent actualizar = new Intent(this, com.example.e_bar.actualizarProducto.class);
                startActivity(actualizar);
                return true;
            case R.id.item5:
                Intent asignarMesa = new Intent(this, com.example.e_bar.asignarMesa.class);
                startActivity(asignarMesa);
                return true;
            case R.id.item6:
                Intent mesaAsignada= new Intent(this, com.example.e_bar.listaMesas.class);
                startActivity(mesaAsignada);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }


}

