package com.example.e_bar.logica;

import com.example.e_bar.Word.mesa;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;

public class barServiceArchive
{
    public static final int TAMANIO_NOMBRE = 25;

    private static String nombreArchivo = "mesaClientes.txt";

    private static String rutaArchivo ="";


    public static void asignarArchivo(String ruta)
    {
        rutaArchivo = ruta;
    }


    public static void agregarMesaCliente(mesa mesa){
        RandomAccessFile raf;
        File file;

        file = new File(rutaArchivo, nombreArchivo);

        try{

            raf = new RandomAccessFile(file, "rw");

            raf.seek(file.length());

            raf.writeInt(mesa.getNumMesa());

            raf.writeUTF(mesa.getClienteMesa());

            raf.close();

        }catch(Exception e){

            System.out.println("error" + e.toString());

        }
    }

    public static String setTamanioNombre(String nombre){
        String res = "";

        if(nombre.length() > TAMANIO_NOMBRE){

            return nombre.substring(0, TAMANIO_NOMBRE);

        }

        for(int i = 0 ; i < (TAMANIO_NOMBRE-nombre.length()) ; i++){

            res = res + " ";

        }

        return nombre+res;

    }

    public static ArrayList<String> leerMesas(){

        ArrayList<String> mesas = new ArrayList<>();

        String cad = "";

        int numMesa;

        String cliente;

        RandomAccessFile raf;

        File file;
        file = new File(rutaArchivo, nombreArchivo);

        try {

            raf = new RandomAccessFile(file, "rw");

            raf.seek(0);

            while (raf.getFilePointer() < file.length()){

                numMesa = raf.readInt();

                cliente = raf.readUTF();

                cad = cad + "Numero de mesa: "+ numMesa + " Cliente: " + cliente+ "\n";

                mesas.add(cad);

            }

            raf.close();
        }catch (Exception e){

            System.out.println("error" + e.toString());

        }

        return mesas;
    }

}
