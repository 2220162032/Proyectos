package com.example.e_bar;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.e_bar.logica.barServiceDB;
import com.example.e_bar.logica.produc;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Objects;

public class factura extends AppCompatActivity {


    private ListView listCompra;
    private Button total;
    private TextView precio;
    private TextView fecha;
    private barServiceDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_factura);

        listCompra =(ListView) findViewById(R.id.listViTotal);

        precio = (TextView)findViewById(R.id.txtTotal);

        total = (Button) findViewById(R.id.btnTotal);

        fecha = (TextView)findViewById(R.id.txtFecha);

        ArrayList<produc> lista = new ArrayList<produc>();

        db = new barServiceDB(this);



//        ArrayAdapter<produc> adapter= new ArrayAdapter<produc>(factura.this,android.R.layout.simple_list_item_1, barService.getTotal());
//        listCompra.setAdapter(adapter);





        ArrayList<String>  listaProductos = null;
         listCompra = findViewById(R.id.listViTotal);

        listaProductos = db.getListaProd();

        ArrayAdapter<String> adaptador = new ArrayAdapter<>(factura.this, android.R.layout.simple_list_item_1, listaProductos);

        listCompra.setAdapter(adaptador);

    }

      public void  verTotal(View view){
          precio.setText("El total de su compra : "+ String.valueOf(db.getTotalPrecio()));

      }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_principal_1, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item1:
                Intent bar = new Intent(this, com.example.e_bar.bar.class);
                startActivity(bar);
                return true;
            case R.id.item2:
                Intent factura = new Intent(this, com.example.e_bar.factura.class);
                startActivity(factura);
                return true;
            case R.id.item3:
                Intent Eliminar = new Intent(this, com.example.e_bar.eliminar.class);
                startActivity(Eliminar);
                return true;
            case R.id.item4:
                Intent actualizar = new Intent(this, com.example.e_bar.actualizarProducto.class);
                startActivity(actualizar);
                return true;
            case R.id.item5:
                Intent asignarMesa = new Intent(this, com.example.e_bar.asignarMesa.class);
                startActivity(asignarMesa);
                return true;
            case R.id.item6:
                Intent mesaAsignada= new Intent(this, com.example.e_bar.listaMesas.class);
                startActivity(mesaAsignada);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }





}
