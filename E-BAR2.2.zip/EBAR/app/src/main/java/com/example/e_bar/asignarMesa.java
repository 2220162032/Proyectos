package com.example.e_bar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.e_bar.Word.mesa;
import com.example.e_bar.logica.barServiceArchive;

public class asignarMesa extends AppCompatActivity {
    private EditText txtNumMesa;
    private EditText txtCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adignar_mesa);

        txtNumMesa = (EditText)findViewById(R.id.txtNumMesa);

        txtCliente = (EditText)findViewById(R.id.txtCliente);
    }


    public void btnAgregarMesa(View view)
    {
        int numMesa;
        String Cliente;
        mesa clienteM;

        numMesa= Integer.parseInt(txtNumMesa.getText().toString());
        Cliente = txtCliente.getText().toString();
        Cliente = barServiceArchive.setTamanioNombre(Cliente);
        clienteM = new mesa(numMesa, Cliente);

        barServiceArchive.agregarMesaCliente(clienteM);

        Toast.makeText(this,"Mesa asignada",Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_principal_1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item1:
                Intent bar = new Intent(this, com.example.e_bar.bar.class);
                startActivity(bar);
                return true;
            case R.id.item2:
                Intent factura = new Intent(this, com.example.e_bar.factura.class);
                startActivity(factura);
                return true;
            case R.id.item3:
                Intent Eliminar = new Intent(this, com.example.e_bar.eliminar.class);
                startActivity(Eliminar);
                return true;
            case R.id.item4:
                Intent actualizar = new Intent(this, com.example.e_bar.actualizarProducto.class);
                startActivity(actualizar);
                return true;
            case R.id.item5:
                Intent asignarMesa = new Intent(this, com.example.e_bar.asignarMesa.class);
                startActivity(asignarMesa);
                return true;
            case R.id.item6:
                Intent mesaAsignada= new Intent(this, com.example.e_bar.listaMesas.class);
                startActivity(mesaAsignada);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
