package com.example.e_bar.logica;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.e_bar.R;

import java.util.ArrayList;

import static com.example.e_bar.logica.barService.productos;

public class producAdapter extends ArrayAdapter<produc> {

    private Context context;

    private int resource;

    private ArrayList<produc> produc;

    public producAdapter(@NonNull Context context, int resource, @NonNull ArrayList<produc> objects) {
        super(context, resource, objects);

        this.context = context;

        this.resource = resource;

        this.produc = objects;
    }

    public producAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }

    public View getView(int posicion, View view , ViewGroup parent){
        ProductosHolder holder = null;

        if(view == null){

            LayoutInflater inflater = ((Activity) context).getLayoutInflater();

            view  = inflater.inflate(resource,parent,false);

            holder = new ProductosHolder();

            holder.setImagen((ImageView) view.findViewById(R.id.imgLista));

            holder.setTexto((TextView) view.findViewById(R.id.txtLista));

            view.setTag(holder);

        }else{
            holder = (ProductosHolder) view.getTag();
        }

        produc producto  = productos.get(posicion);
        holder.setTexto(producto.getNombre()+" --Cantidad: "
                +producto.getCantidad()+" --Preció unidad: $"
                +producto.getPrecio());
       // holder.setImagen(producto.getIcono());
        return view;
    }

    //Clase estatica Holder
    static class ProductosHolder {

        private ImageView imagen;

        private TextView texto;


        public ImageView getImagen() {
            return imagen;
        }

        public void setImagen(ImageView imagen) {
            this.imagen = imagen;
        }

        public TextView getTexto() {
            return texto;
        }

        public void setTexto(TextView texto) {
            this.texto = texto;
        }

        public void setImagen(int imagen) {
            this.imagen.setImageResource(imagen);
        }

        public void setTexto(String texto) {
            this.texto.setText(texto);
        }
    }


}
