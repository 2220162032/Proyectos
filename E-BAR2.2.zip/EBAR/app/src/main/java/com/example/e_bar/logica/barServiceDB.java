package com.example.e_bar.logica;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class barServiceDB extends SQLiteOpenHelper {

    public final static String DATABASE_NAME = "DBBARF.db";
    public final static String TABLE_NAME_PRODUCTO= "PRODUCTO";
    public final static String ATRIBUTE_SERIAL = "SERIAL";
    public final static String ATRIBUTE_PRECIO = "PRECIO";
    public final static String ATRIBUTE_NOMBRE= "NOMBRE";
    public final static String ATRIBUTE_CANTIDAD = "CANTIDAD";
    //public final static String ATRIBUTE_ICONO= "ICONO";

    public barServiceDB(@Nullable Context context) {
        super(context,DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String cadSQLPro = "";

        cadSQLPro = "CREATE TABLE " +  TABLE_NAME_PRODUCTO +"( " + ATRIBUTE_SERIAL +" INTEGER PRIMARY KEY, " +ATRIBUTE_NOMBRE + " TEXT, "+ ATRIBUTE_PRECIO + " INTEGER, "+ ATRIBUTE_CANTIDAD  + " INTEGRER)";

        db.execSQL(cadSQLPro);

    }


    public boolean addProducto(produc prod)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues;
        long resultado;

        contentValues = new ContentValues();
        contentValues.put(ATRIBUTE_SERIAL, prod.getSerial());
        contentValues.put(ATRIBUTE_NOMBRE, prod.getNombre());
        contentValues.put(ATRIBUTE_PRECIO, prod.getPrecio());
        contentValues.put(ATRIBUTE_CANTIDAD, prod.getCantidad());
        //contentValues.put(ATRIBUTE_ICONO, prod.getIcono());

        resultado = db.insert(TABLE_NAME_PRODUCTO,null, contentValues);

        if(resultado == -1){

            return false;
        }
        else
        {
            return true;
        }


    }

    public ArrayList<String> getListaProd(){

        ArrayList<String>productos = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = null;
        String cadProducto;
        String cadSQL = "";

        cadSQL = "SELECT * FROM " + TABLE_NAME_PRODUCTO;

        res = db.rawQuery(cadSQL, null);

        while (res.moveToNext())
        {

            cadProducto = res.getString(0) + " - " + res.getString(1) + " - " + res.getString(2)+ " - " +res.getString(3) ;
            productos.add(cadProducto);
        }

        return productos;
    }

    public int getTotalPrecio(){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = null;
        String cadSQL = "";
        int precio;
        int cantidad;
        int total = 0;

        cadSQL = "SELECT * FROM " + TABLE_NAME_PRODUCTO;

        res = db.rawQuery(cadSQL, null);

        while (res.moveToNext())
        {
            precio = Integer.parseInt(res.getString(2));
            cantidad = Integer.parseInt(res.getString(3));
            total = total + (precio * cantidad);
       }
        return total;
    }


    public produc leerProductoDB(int serial)
    {
        produc prod = null;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = null;
        String cadSql = "";
        int serialPro =0;
        String nombre;
        int precio= 0;
        int cantidad = 0;


        cadSql = "SELECT * FROM "+ TABLE_NAME_PRODUCTO + " WHERE " +ATRIBUTE_SERIAL + " = " + serial;

        res = db.rawQuery(cadSql, null);

        while (res.moveToNext()) {
            serialPro = Integer.parseInt(res.getString(0));
            nombre = res.getString(1);
            precio = Integer.parseInt(res.getString(2));
            cantidad = Integer.parseInt(res.getString(3));
            if (serialPro == serial){
                prod= new produc(serialPro,nombre,precio, cantidad);
            }
        }
        return prod;
    }

    public void eliminarProducto(int serial)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String cadSQL = "";

        cadSQL = "DELETE FROM " + TABLE_NAME_PRODUCTO  + " WHERE " + ATRIBUTE_SERIAL + " = " + serial;

        db.execSQL(cadSQL);
    }

    public void actualizarProducto(int serial, int cantidad)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String cadSQL = "";

        cadSQL = "UPDATE " + TABLE_NAME_PRODUCTO  +  " SET " +ATRIBUTE_CANTIDAD + " = " + cantidad +
                " WHERE " + ATRIBUTE_SERIAL + " = " + serial;

        db.execSQL(cadSQL);

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}
