package com.example.e_bar.logica;

import android.widget.EditText;

public class produc {


    public produc(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

   /* public int getIcono() {
        return icono;
    }

    public void setIcono(int icono) {
        this.icono = icono;
    }
*/
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    private int serial;

    public int getSerial() {
        return serial;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }


    public produc() {
        this.precio = 0;
        this.nombre = "N.N";

    }

    private String nombre;

    public int getPrecio() {
        return precio;
    }

    private int precio;

    private int cantidad;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    private  int codigo;


    private int icono;

    public produc(int serial ,String nombre, int precio, int cantidad) {

        this.serial = serial;

        this.nombre = nombre;

        this.precio = precio;

        this.cantidad = cantidad;

       // this.icono = icono ;
    }

    @Override
    public String toString() {
          return nombre+" precio$"+precio+" c "+cantidad;
}
}
