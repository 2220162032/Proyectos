package com.example.e_bar;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.e_bar.logica.barServiceDB;
import com.example.e_bar.logica.produc;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Objects;

public class eliminar extends AppCompatActivity {

    private EditText txtNombre;
    private FirebaseFirestore df;
    private EditText txtPrecio;
    private EditText txtCantidad;
    private EditText txtSerial;
    private barServiceDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);

        db = new barServiceDB(this);
        txtSerial = (EditText) findViewById(R.id.txtSerial);
        txtPrecio = (EditText) findViewById(R.id.txtPrecio);
        txtCantidad = (EditText) findViewById(R.id.txtCantidad);
        txtNombre = (EditText) findViewById(R.id.txtNombre);
        df = FirebaseFirestore.getInstance();
    }


    public void btnEliminarProducto(View view) {
        int serial;

        serial = Integer.parseInt(txtSerial.getText().toString());

        db.eliminarProducto(serial);
        Toast.makeText(this, "Se a eliminado el producto", Toast.LENGTH_SHORT).show();
    }


    public void btnBuscar_Click(View view) {
        int serial;
        produc prod;

        serial = Integer.parseInt(txtSerial.getText().toString());
        prod = db.leerProductoDB(serial);
        if (prod == null) {
            Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show();
        } else {
            txtNombre.setText(prod.getNombre());
            txtPrecio.setText(String.valueOf(prod.getPrecio()));
            txtCantidad.setText(String.valueOf(prod.getCantidad()));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_principal_1, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item1:
                Intent bar = new Intent(this, com.example.e_bar.bar.class);
                startActivity(bar);
                return true;
            case R.id.item2:
                Intent factura = new Intent(this, com.example.e_bar.factura.class);
                startActivity(factura);
                return true;
            case R.id.item3:
                Intent Eliminar = new Intent(this, com.example.e_bar.eliminar.class);
                startActivity(Eliminar);
                return true;
            case R.id.item4:
                Intent actualizar = new Intent(this, com.example.e_bar.actualizarProducto.class);
                startActivity(actualizar);
                return true;
            case R.id.item5:
                Intent asignarMesa = new Intent(this, com.example.e_bar.asignarMesa.class);
                startActivity(asignarMesa);
                return true;
            case R.id.item6:
                Intent mesaAsignada = new Intent(this, com.example.e_bar.listaMesas.class);
                startActivity(mesaAsignada);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }

    public void eliminarF(View view) {
        df.collection("E-BAR").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                                produc pro = document.toObject(produc.class);
                                int codigo = 0;
                                if (codigo == pro.getCodigo()) {
                                    df.collection("E-BAR").document(String.valueOf(codigo)).delete();
                                }
                            }
                        }
                    }
                });

    }
    public  void eliminarLogico(View view){
        df.collection("E-BAR").get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                                produc pro = document.toObject(produc.class);
                                int codigo = 0;
                                if (codigo == pro.getSerial()) {
                                    DocumentReference documentReference = df.collection("E-BAR")
                                            .document(codigo+"");

                                    documentReference.update("estado", "EL");
                                }
                            }
                        }
                    }
                });
    }

}


