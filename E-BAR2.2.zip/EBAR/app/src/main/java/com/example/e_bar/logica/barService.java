package com.example.e_bar.logica;

import java.util.ArrayList;

public class barService {


    public  static ArrayList<produc> productos= new ArrayList<produc>();

    public static void adicionarProducto(produc p) {

        productos.add(p);
    }

    public static int total(){
        int total=0;
        for (produc productos : productos){

            total = total + (productos.getPrecio()*productos.getCantidad());

        }

        return total;

    }
    public static ArrayList<produc> getTotal() {

        return productos;
    }

}
