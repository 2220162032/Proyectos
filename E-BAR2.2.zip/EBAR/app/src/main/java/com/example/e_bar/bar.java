package com.example.e_bar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_bar.logica.barServiceDB;
import com.example.e_bar.logica.produc;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

public class bar extends AppCompatActivity {
    private FirebaseFirestore df;
    private Button btnAgregar, btnFactura;
    private CheckBox checCosteña;
    private CheckBox checWiskey;
    private CheckBox checPapas;
    private TextView txtCantidad;
    final static int numSerialCosteña =1;
    final static int numSerialJack = 2;
    final static int numSerialPapas = 3;
    final static String nomCosteña = "Costeña";
    final static String nomWiskey = "Whiskey";
    final static String nomPapas = "Papas";
    final static int PrecioCosteña = 2200;
    final static int PrecioWiskey = 200000;
    final static int PrecioPapas = 9000;
    private barServiceDB db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bar);

        btnAgregar =  (Button) findViewById(R.id.btnAgregar);

        btnFactura =  (Button) findViewById(R.id.btnTotal);

        checCosteña = (CheckBox) findViewById(R.id.checCosteña);

        checWiskey = (CheckBox) findViewById(R.id.cheWisky);

        checPapas = (CheckBox) findViewById(R.id.checPapas);

        txtCantidad = (TextView) findViewById(R.id.txtCantidad);

        db = new barServiceDB(this);
        df = FirebaseFirestore.getInstance();


    }
//    public void facturas(View view){
//        Intent facturas = new Intent(this,factura.class);
//        startActivity(facturas);
//    }

    public void btnAgrgar (View view){

        produc c,w,p;

        if(checCosteña.isChecked()){
            int cantidad =Integer.parseInt(txtCantidad.getText().toString());
            c = new produc(numSerialCosteña,nomCosteña,PrecioCosteña,
                    Integer.parseInt(txtCantidad.getText().toString()));
                    db.addProducto(c);
            Toast.makeText(this,"Se agrego al carrito  ",Toast.LENGTH_LONG).show();
        }
        else if (checWiskey.isChecked())
        {
            int cantidad =Integer.parseInt(txtCantidad.getText().toString());
            w = new produc(numSerialJack,nomWiskey,PrecioWiskey,
                    Integer.parseInt(txtCantidad.getText().toString()));

            db.addProducto(w);
            Toast.makeText(this,"Se agrego al carrito  ",Toast.LENGTH_LONG).show();
        }
        else if (checPapas.isChecked())
        {
            int cantidad =Integer.parseInt(txtCantidad.getText().toString());
            p = new produc(numSerialPapas,nomPapas,PrecioPapas,
                    Integer.parseInt(txtCantidad.getText().toString()));

            db.addProducto(p);
            Toast.makeText(this,"Se agrego al carrito  ",Toast.LENGTH_LONG).show();
        }




    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_principal_1, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item1:
                Intent bar = new Intent(this, com.example.e_bar.bar.class);
                startActivity(bar);
                return true;
            case R.id.item2:
                Intent factura = new Intent(this, com.example.e_bar.factura.class);
                startActivity(factura);
                return true;
            case R.id.item3:
                Intent Eliminar = new Intent(this, com.example.e_bar.eliminar.class);
                startActivity(Eliminar);
                return true;
            case R.id.item4:
                Intent actualizar = new Intent(this, com.example.e_bar.actualizarProducto.class);
                startActivity(actualizar);
                return true;
            case R.id.item5:
                Intent asignarMesa = new Intent(this, com.example.e_bar.asignarMesa.class);
                startActivity(asignarMesa);
                return true;
            case R.id.item6:
                Intent mesaAsignada= new Intent(this, com.example.e_bar.listaMesas.class);
                startActivity(mesaAsignada);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }
    public void btnAdicionar_Click(View view){
         produc pro = new produc("galletas", 200);

        df.collection("E-BAR")
                .document(String.valueOf(pro.getPrecio()))
                .set(pro).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(bar.this,"Producto adicionado!",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(bar.this,"Producto NO adicionado!",Toast.LENGTH_LONG).show();
                }

            }


        });

    }




}


