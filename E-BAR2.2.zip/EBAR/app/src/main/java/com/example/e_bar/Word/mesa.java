package com.example.e_bar.Word;

public class mesa {


    int numMesa;
    String clienteMesa;

    public mesa(int numMesa, String clienteMesa) {
        this.numMesa = numMesa;
        this.clienteMesa = clienteMesa;
    }

    public int getNumMesa() {
        return numMesa;
    }

    public void setNumMesa(int numMesa) {
        this.numMesa = numMesa;
    }

    public String getClienteMesa() {
        return clienteMesa;
    }

    public void setClienteMesa(String clienteMesa) {
        this.clienteMesa = clienteMesa;
    }


}
